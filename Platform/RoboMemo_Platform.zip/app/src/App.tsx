import { useState } from 'react';
import { 
  Database, 
  Play, 
  Tag, 
  BarChart3, 
  Cpu, 
  Sparkles,
  Settings,
  Menu,
  Wand2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import DatasetManager from '@/sections/DatasetManager';
import DataCollection from '@/sections/DataCollection';
import DataAnnotation from '@/sections/DataAnnotation';
import DataVisualization from '@/sections/DataVisualization';
import SimulatorControl from '@/sections/SimulatorControl';
import DataAugmentation from '@/sections/DataAugmentation';
import AutoAnnotation from '@/sections/AutoAnnotation';
import PlatformStats from '@/sections/PlatformStats';
import './App.css';

type Tab = 'datasets' | 'collection' | 'annotation' | 'visualization' | 'simulators' | 'augmentation' | 'autoannotation' | 'stats';

const tabs = [
  { id: 'datasets' as Tab, label: 'Datasets', icon: Database },
  { id: 'collection' as Tab, label: 'Collection', icon: Play },
  { id: 'annotation' as Tab, label: 'Annotation', icon: Tag },
  { id: 'autoannotation' as Tab, label: 'Auto-Annotation', icon: Wand2 },
  { id: 'visualization' as Tab, label: 'Visualization', icon: BarChart3 },
  { id: 'simulators' as Tab, label: 'Simulators', icon: Cpu },
  { id: 'augmentation' as Tab, label: 'Augmentation', icon: Sparkles },
  { id: 'stats' as Tab, label: 'Statistics', icon: BarChart3 },
];

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('datasets');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const renderContent = () => {
    switch (activeTab) {
      case 'datasets':
        return <DatasetManager />;
      case 'collection':
        return <DataCollection />;
      case 'annotation':
        return <DataAnnotation />;
      case 'visualization':
        return <DataVisualization />;
      case 'simulators':
        return <SimulatorControl />;
      case 'augmentation':
        return <DataAugmentation />;
      case 'autoannotation':
        return <AutoAnnotation />;
      case 'stats':
        return <PlatformStats />;
      default:
        return <DatasetManager />;
    }
  };

  return (
    <div className="min-h-screen bg-background flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 flex-col border-r bg-card">
        <div className="p-6 border-b">
          <h1 className="text-xl font-bold text-primary">Embodied Data Platform</h1>
          <p className="text-xs text-muted-foreground mt-1">v1.0.0</p>
        </div>
        
        <nav className="flex-1 p-4 space-y-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  activeTab === tab.id
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground'
                }`}
              >
                <Icon className="w-5 h-5" />
                {tab.label}
              </button>
            );
          })}
        </nav>
        
        <div className="p-4 border-t">
          <Button variant="outline" className="w-full" size="sm">
            <Settings className="w-4 h-4 mr-2" />
            Settings
          </Button>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 bg-card border-b">
        <div className="flex items-center justify-between p-4">
          <h1 className="text-lg font-bold">Embodied Data Platform</h1>
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="w-6 h-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 p-0">
              <div className="p-6 border-b">
                <h1 className="text-xl font-bold">Embodied Data Platform</h1>
              </div>
              <nav className="p-4 space-y-1">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => {
                        setActiveTab(tab.id);
                        setIsMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                        activeTab === tab.id
                          ? 'bg-primary text-primary-foreground'
                          : 'text-muted-foreground hover:bg-accent'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      {tab.label}
                    </button>
                  );
                })}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 overflow-auto lg:pt-0 pt-16">
        <div className="p-6 lg:p-8">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}

export default App;
